# Monish - Kendriya Vidyalaya (Student Project Website)

This is a ready-to-deploy static website template created for Monish (Class 11) as a Kendriya Vidyalaya school project.

## What is included
- `index.html` — main website
- `styles.css` — site styles
- `script.js` — small JS helper
- `netlify.toml` — Netlify config (simple)
- `README.md` — this file

## How to deploy to Netlify (quick)
1. Download or unzip this repository locally.
2. Create a new GitHub repository and push these files to the repository root.
3. Go to https://www.netlify.com and sign in.
4. Click **New site from Git**, connect GitHub, and select your repo.
5. Set build command to empty and publish directory to `/` (root). For static HTML sites Netlify will deploy directly.
6. Click **Deploy site**. Netlify will provide a URL. (Optional: add custom domain in Netlify settings)

## How to deploy to GitHub Pages
1. Create a GitHub repo and push files to the `gh-pages` branch or main branch.
2. In repo settings -> Pages, select branch and root, then save.
3. GitHub Pages will publish the site.

## Editing content
- Open `index.html` and edit the text blocks to replace school address, phone, and gallery images.
- Add images to `/assets/images` and update `index.html` accordingly.

## Netlify Forms
The contact form is configured for Netlify Forms. When deployed on Netlify, messages will be collected in Site > Forms.

